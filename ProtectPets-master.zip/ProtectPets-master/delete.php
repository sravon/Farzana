<?php
require 'dbcon.php';

$reg_id = $_GET['id'];
$sql = "DELETE FROM registration WHERE id='$reg_id'";
$delete = mysqli_query($con,$sql );

if($delete){
  echo "<script>
        alert('Data Deleted!');
        window.location.href= 'select.php';
        </script>
  ";
  exit;
}

 ?>
