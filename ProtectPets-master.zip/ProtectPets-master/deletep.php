<?php
session_start();
include('dbcon.php');
if(isset($_GET["id"]))
{
    $post_id = $_GET["id"];
    $user_id = $_SESSION["id"];
    $qry = "DELETE FROM post WHERE post_id = '$post_id' AND post_user = '$user_id'";
    if (mysqli_query($con, $qry)) {
        $_SESSION["msg"] = "Note Deleted";
        header('location:index.php');
    } else {
        $_SESSION["msg"] = "Error";
        header('location:index.php');
    }
}
?>