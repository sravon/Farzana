<?php
require 'dbcon.php';
$reg_id = $_GET['id'];
$sql = "SELECT * FROM registration WHERE id='$reg_id'";
$get_reg = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($get_reg);

?>
<form action="update.php?id=<?=$row['id']?>" method="post">
	User Name :<input type="text" name="username" value="<?=$row['username']; ?>"><br>
	Email :<input type="email" name="email" value="<?=$row['email']; ?>" ><br>
	Division :<input type="text" name="division" value="<?=$row['division'];?>"><br>
	Post Code :<input type="number" name="postcode" value="<?=$row['postcode'];?>"><br>
	<input type="submit" name="update" value="update">
</form>