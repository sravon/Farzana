<footer>
	<p class="p-3 bg-dark text-white text-center">Protect Pets<br>Developed by Amirul Ahsan  | | Ishrat Jahan Preety | | Abu Sufian <br>Copyright &copy; 2021 Protec Pets</p>
</footer>