<?php
require 'dbcon.php';
$username = $_POST['username'];
$email = $_POST['email'];
$division = $_POST['division'];
$postcode = $_POST['postcode'];
$reg_id = $_GET['id'];

$sql = "UPDATE registration SET username='$username', email = '$email', division='$division', postcode='$postcode' WHERE id='$reg_id'";
$update = mysqli_query($con, $sql);
if($update){
	header('location: ','select.php');
}else{
	echo 'try again';
}
?>